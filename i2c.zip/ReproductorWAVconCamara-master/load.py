#!/usr/bin/env python3
import os
os.system("djtgcfg prog -d Nexys4 --index 0 --file ./build/gateware/top.bit")
